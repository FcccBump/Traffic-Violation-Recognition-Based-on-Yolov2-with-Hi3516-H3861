
<!-- 文件夹 -->
# ai_infer_process ：AI处理相关
# dependency ：音频播放相关函数
# ext_util ：socket 相关函数以及其他一些数据处理函数
# interconnection_server ：和 Pedasus wifi 通信相关
# jpeg ：libjpeg 开源库
# mpi ：libmpi.a 静态库
# mpp ：海思媒体处理平台包含的函数相关
# scenario ：子文件夹内包含重要函数：模型加载以及创建各个模块线程，模型推理以及相应后处理与各模块执行
# smp ：代码入口，配置系统初始化相关
# third_party ： opencv 相关
